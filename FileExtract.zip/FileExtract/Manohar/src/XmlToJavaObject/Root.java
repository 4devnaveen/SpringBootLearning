package XmlToJavaObject;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "root")
@XmlAccessorType(XmlAccessType.FIELD)
public class Root {

    @XmlElement(name = "press")
    private Press press;

    // Getters and setters
    public Press getPress() {
        return press;
    }

    public void setPress(Press press) {
        this.press = press;
    }
}
