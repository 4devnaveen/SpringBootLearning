package XmlToJavaObject;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class Row {

    @XmlElement(name = "volume")
    private String volume;

    @XmlElement(name = "issue")
    private String issue;

    @XmlElement(name = "issue-sequence")
    private String issueSequence;

    @XmlElement(name = "aid")
    private String aid;

    @XmlElement(name = "sh")
    private String sh;

    @XmlElement(name = "tspages")
    private String tsPages;

    @XmlElement(name = "startpage")
    private String startPage;

    @XmlElement(name = "endpage")
    private String endPage;

    @XmlElement(name = "onlinepublishdate")
    private String onlinePublishDate;

    @XmlElement(name = "printpublishdate")
    private String printPublishDate;

    // Getters and setters
    public String getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public String getIssueSequence() {
        return issueSequence;
    }

    public void setIssueSequence(String issueSequence) {
        this.issueSequence = issueSequence;
    }

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getSh() {
        return sh;
    }

    public void setSh(String sh) {
        this.sh = sh;
    }

    public String getTsPages() {
        return tsPages;
    }

    public void setTsPages(String tsPages) {
        this.tsPages = tsPages;
    }

    public String getStartPage() {
        return startPage;
    }

    public void setStartPage(String startPage) {
        this.startPage = startPage;
    }

    public String getEndPage() {
        return endPage;
    }

    public void setEndPage(String endPage) {
        this.endPage = endPage;
    }

    public String getOnlinePublishDate() {
        return onlinePublishDate;
    }

    public void setOnlinePublishDate(String onlinePublishDate) {
        this.onlinePublishDate = onlinePublishDate;
    }

    public String getPrintPublishDate() {
        return printPublishDate;
    }

    public void setPrintPublishDate(String printPublishDate) {
        this.printPublishDate = printPublishDate;
    }
}
