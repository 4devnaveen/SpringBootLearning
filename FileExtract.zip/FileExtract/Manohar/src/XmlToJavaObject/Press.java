package XmlToJavaObject;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
public class Press {

    @XmlElement(name = "row")
    private List<Row> rows;

    // Getters and setters
    public List<Row> getRows() {
        return rows;
    }



    public void setRows(List<Row> rows) {
        this.rows = rows;
    }
}

