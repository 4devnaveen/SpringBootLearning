package XmlToJavaObject;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;

import java.io.File;
import java.util.List;

public class Parsing {


        public static void main(String[] args) throws JAXBException, JAXBException {
            File xmlFile = new File("C:/Users/21003/Downloads/Requirement_PDF/Requirement_PDF/Input_XML/AHP_37_4.xml"); // Path to your XML file

            // Create JAXB context and unmarshaller
            JAXBContext jaxbContext = JAXBContext.newInstance(Root.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

            // Unmarshal XML to Java object
            Root root = (Root) jaxbUnmarshaller.unmarshal(xmlFile);

            // Get the press from the root
            Press press = root.getPress();

            // Get the list of rows from press
            List<Row> rows = press.getRows();

            int i=0;
            // Print information for each row
            for (Row row : rows) {
                i++;
                System.out.println("Volume: " + row.getVolume());
                System.out.println("Issue: " + row.getIssue());
                System.out.println("Issue Sequence: " + row.getIssueSequence());
                System.out.println("AID: " + row.getAid());
                System.out.println("SH: " + row.getSh());
                System.out.println("TS Pages: " + row.getTsPages());
                System.out.println("Start Page: " + row.getStartPage());
                System.out.println("End Page: " + row.getEndPage());
                System.out.println("Online Publish Date: " + row.getOnlinePublishDate());
                System.out.println("Print Publish Date: " + row.getPrintPublishDate());
                System.out.println((i)+" "+ "Row is completed");
                System.out.println("\n");
            }
        }
    }

